import logging
import os
import asyncio
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandStart
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder
import yt_dlp
import re

# === SOZLAMALAR ===
BOT_TOKEN = os.getenv("BOT_TOKEN", "8816584321:AAG7goREJmlxSnWB9MSKap8qVnp9gdaNOmA")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Foydalanuvchi holati
user_state = {}
user_playlists = {}  # {user_id: [{"title": ..., "url": ...}]}

# ===================== YORDAMCHI FUNKSIYALAR =====================

def search_music(query: str, max_results: int = 5):
    """Musiqa qidirish (YouTube orqali)"""
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'extract_flat': True,
        'default_search': 'ytsearch',
        'noplaylist': True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        result = ydl.extract_info(f"ytsearch{max_results}:{query}", download=False)
        if result and 'entries' in result:
            return result['entries']
    return []

def download_audio(url: str, output_path: str = "/tmp"):
    """Audio yuklab olish"""
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': f'{output_path}/%(title)s.%(ext)s',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'quiet': True,
        'no_warnings': True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get('title', 'audio')
        # mp3 fayl nomini topamiz
        filename = ydl.prepare_filename(info)
        filename = filename.rsplit('.', 1)[0] + '.mp3'
        return filename, title

def format_duration(seconds):
    if not seconds:
        return "?"
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"

# ===================== BOSHLASH =====================

@dp.message(CommandStart())
async def start(message: types.Message):
    kb = InlineKeyboardBuilder()
    kb.button(text="🎵 Qo'shiq qidirish", callback_data="menu_song")
    kb.button(text="🎤 Artist qidirish", callback_data="menu_artist")
    kb.button(text="📋 Mening pleylistim", callback_data="menu_my")
    kb.button(text="🔥 Top qo'shiqlar", callback_data="menu_top")
    kb.button(text="⚙️ Sozlamalar", callback_data="menu_settings")
    kb.button(text="❓ Yordam", callback_data="menu_help")
    kb.adjust(2, 2, 2)

    await message.answer(
        "🎶 *Xush kelibsiz! Musiqa Botga!* 👋\n\n"
        "Men siz uchun istalgan qo'shiqni topib, yuklab beraman!\n\n"
        "YouTube, Instagram, Spotify, TikTok va boshqa platformalardan musiqa qidira olasiz.\n\n"
        "*Buyruqlar:*\n"
        "• /song — qo'shiq nomi orqali qidirish\n"
        "• /artist — qo'shiqchi ismi orqali qidirish\n"
        "• /my — sizning pleylistlaringiz ro'yhati\n"
        "• /top — mashhur qo'shiqlar\n"
        "• /settings — sozlamalarni o'zgartirish\n"
        "• /help — yordam ko'rsatish\n\n"
        "🔗 *Shuningdek, link yuboring* — men uni yuklab beraman!",
        parse_mode="Markdown",
        reply_markup=kb.as_markup()
    )

@dp.message(Command("help"))
async def help_cmd(message: types.Message):
    await message.answer(
        "❓ *Yordam*\n\n"
        "🎵 *Qo'shiq qidirish:*\n"
        "Faqat qo'shiq nomini yozing yoki /song buyrug'ini ishlating\n\n"
        "🔗 *Link orqali yuklab olish:*\n"
        "YouTube, Instagram, TikTok, Spotify linkini yuboring\n\n"
        "🎤 *Artist bo'yicha:*\n"
        "/artist [artist ismi]\n\n"
        "📋 *Pleylist:*\n"
        "/my — saqlangan qo'shiqlaringiz\n\n"
        "🔥 *Top qo'shiqlar:*\n"
        "/top — eng ko'p tinglangan qo'shiqlar",
        parse_mode="Markdown"
    )

@dp.message(Command("song"))
async def song_cmd(message: types.Message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        user_state[message.from_user.id] = "waiting_song"
        await message.answer("🎵 Qo'shiq nomini yozing:")
        return
    await do_search(message, args[1])

@dp.message(Command("artist"))
async def artist_cmd(message: types.Message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        user_state[message.from_user.id] = "waiting_artist"
        await message.answer("🎤 Artist ismini yozing:")
        return
    await do_search(message, args[1] + " songs")

@dp.message(Command("my"))
async def my_playlist(message: types.Message):
    uid = message.from_user.id
    playlist = user_playlists.get(uid, [])
    if not playlist:
        await message.answer("📋 Sizning pleylistingiz bo'sh.\n\nQo'shiq topganingizda ❤️ tugmasini bosing!")
        return
    
    kb = InlineKeyboardBuilder()
    for i, item in enumerate(playlist[:10]):
        kb.button(text=f"🎵 {item['title'][:30]}", callback_data=f"play_{i}")
        kb.button(text="🗑", callback_data=f"del_{i}")
    kb.adjust(2)
    
    await message.answer(
        f"📋 *Sizning pleylistingiz* ({len(playlist)} ta qo'shiq):",
        parse_mode="Markdown",
        reply_markup=kb.as_markup()
    )

@dp.message(Command("top"))
async def top_songs(message: types.Message):
    msg = await message.answer("🔥 Top qo'shiqlar yuklanmoqda...")
    results = await asyncio.get_event_loop().run_in_executor(
        None, lambda: search_music("top hits 2024 2025", 8)
    )
    await show_results(msg, results, edit=True)

@dp.message(Command("settings"))
async def settings_cmd(message: types.Message):
    kb = InlineKeyboardBuilder()
    kb.button(text="🎵 Sifat: MP3 192kbps", callback_data="setting_quality")
    kb.button(text="🌐 Til: O'zbek", callback_data="setting_lang")
    kb.adjust(1)
    await message.answer("⚙️ *Sozlamalar*", parse_mode="Markdown", reply_markup=kb.as_markup())

# ===================== LINK YO MATN QABUL QILISH =====================

URL_PATTERN = re.compile(
    r'(https?://)?(www\.)?(youtube\.com|youtu\.be|instagram\.com|tiktok\.com|'
    r'open\.spotify\.com|music\.apple\.com|soundcloud\.com|vk\.com)[^\s]*'
)

@dp.message(F.text)
async def handle_text(message: types.Message):
    text = message.text.strip()
    uid = message.from_user.id

    # Link bo'lsa — yuklab olish
    if URL_PATTERN.search(text):
        await download_from_url(message, text)
        return

    # Holat bo'yicha
    state = user_state.get(uid)
    if state in ("waiting_song", "waiting_artist", None):
        user_state.pop(uid, None)
        await do_search(message, text)

async def download_from_url(message: types.Message, url: str):
    msg = await message.answer("⏳ Yuklab olinmoqda...")
    try:
        filename, title = await asyncio.get_event_loop().run_in_executor(
            None, lambda: download_audio(url)
        )
        audio = FSInputFile(filename)
        kb = InlineKeyboardBuilder()
        kb.button(text="❤️ Saqlash", callback_data=f"save_{url[:60]}")
        await msg.delete()
        await message.answer_audio(
            audio,
            title=title,
            caption=f"🎵 *{title}*\n\n📥 Yuklab olindi!",
            parse_mode="Markdown",
            reply_markup=kb.as_markup()
        )
        # Faylni o'chirish
        try:
            os.remove(filename)
        except:
            pass
    except Exception as e:
        logger.error(f"Download error: {e}")
        await msg.edit_text(
            "❌ Yuklab olishda xatolik yuz berdi.\n"
            "Bu link ishlamasligi mumkin. Boshqa link sinab ko'ring."
        )

async def do_search(message: types.Message, query: str):
    msg = await message.answer(f"🔍 *{query}* qidirilmoqda...")
    results = await asyncio.get_event_loop().run_in_executor(
        None, lambda: search_music(query, 5)
    )
    await show_results(msg, results, edit=True, query=query)

async def show_results(message: types.Message, results: list, edit=False, query=""):
    if not results:
        text = "❌ Hech narsa topilmadi. Boshqa so'z bilan qidiring."
        if edit:
            await message.edit_text(text)
        else:
            await message.answer(text)
        return

    text = f"🎵 *Natijalar:*\n\n"
    kb = InlineKeyboardBuilder()

    for i, item in enumerate(results[:5]):
        title = item.get('title', 'Noma\'lum')[:50]
        duration = format_duration(item.get('duration'))
        url = item.get('url') or item.get('webpage_url', '')
        
        text += f"{i+1}. 🎵 {title} `[{duration}]`\n"
        kb.button(text=f"{i+1}. ⬇️ {title[:25]}", callback_data=f"dl_{i}_{url[:50]}")

    kb.button(text="🔍 Qayta qidirish", callback_data=f"search_{query[:40]}")
    kb.adjust(1)

    # URL larni saqlash
    for i, item in enumerate(results[:5]):
        url = item.get('url') or item.get('webpage_url', '')
        user_state[f"result_{i}"] = url

    if edit:
        await message.edit_text(text, parse_mode="Markdown", reply_markup=kb.as_markup())
    else:
        await message.answer(text, parse_mode="Markdown", reply_markup=kb.as_markup())

# ===================== CALLBACK HANDLERS =====================

@dp.callback_query(F.data.startswith("dl_"))
async def download_callback(callback: types.CallbackQuery):
    parts = callback.data.split("_", 2)
    idx = int(parts[1])
    url = user_state.get(f"result_{idx}", "")
    
    if not url:
        await callback.answer("❌ URL topilmadi, qaytadan qidiring", show_alert=True)
        return
    
    await callback.answer("⏳ Yuklab olinmoqda...")
    msg = await callback.message.answer("⏳ Yuklab olinmoqda, iltimos kuting...")
    
    try:
        filename, title = await asyncio.get_event_loop().run_in_executor(
            None, lambda: download_audio(url)
        )
        audio = FSInputFile(filename)
        kb = InlineKeyboardBuilder()
        kb.button(text="❤️ Pleylistga saqlash", callback_data=f"savepl_{title[:40]}__{url[:50]}")
        
        await msg.delete()
        await callback.message.answer_audio(
            audio,
            title=title,
            caption=f"🎵 *{title}*",
            parse_mode="Markdown",
            reply_markup=kb.as_markup()
        )
        try:
            os.remove(filename)
        except:
            pass
    except Exception as e:
        logger.error(f"Callback download error: {e}")
        await msg.edit_text("❌ Yuklab olishda xatolik. Qayta urinib ko'ring.")

@dp.callback_query(F.data.startswith("savepl_"))
async def save_to_playlist(callback: types.CallbackQuery):
    parts = callback.data[7:].split("__", 1)
    title = parts[0] if parts else "Noma'lum"
    url = parts[1] if len(parts) > 1 else ""
    
    uid = callback.from_user.id
    if uid not in user_playlists:
        user_playlists[uid] = []
    
    # Takrorlanishni tekshirish
    for item in user_playlists[uid]:
        if item['title'] == title:
            await callback.answer("✅ Allaqachon pleylistda bor!", show_alert=True)
            return
    
    user_playlists[uid].append({"title": title, "url": url})
    await callback.answer(f"❤️ '{title[:20]}' pleylistga saqlandi!", show_alert=True)

@dp.callback_query(F.data.startswith("del_"))
async def delete_from_playlist(callback: types.CallbackQuery):
    idx = int(callback.data[4:])
    uid = callback.from_user.id
    playlist = user_playlists.get(uid, [])
    
    if 0 <= idx < len(playlist):
        removed = playlist.pop(idx)
        await callback.answer(f"🗑 '{removed['title'][:20]}' o'chirildi")
        await my_playlist(callback.message)
    else:
        await callback.answer("❌ Xatolik")

@dp.callback_query(F.data.startswith("play_"))
async def play_from_playlist(callback: types.CallbackQuery):
    idx = int(callback.data[5:])
    uid = callback.from_user.id
    playlist = user_playlists.get(uid, [])
    
    if 0 <= idx < len(playlist):
        item = playlist[idx]
        await callback.answer("⏳ Yuklab olinmoqda...")
        await download_from_url(callback.message, item['url'])
    else:
        await callback.answer("❌ Xatolik")

@dp.callback_query(F.data.startswith("menu_"))
async def menu_callbacks(callback: types.CallbackQuery):
    action = callback.data[5:]
    if action == "song":
        user_state[callback.from_user.id] = "waiting_song"
        await callback.message.answer("🎵 Qo'shiq nomini yozing:")
    elif action == "artist":
        user_state[callback.from_user.id] = "waiting_artist"
        await callback.message.answer("🎤 Artist ismini yozing:")
    elif action == "my":
        await my_playlist(callback.message)
    elif action == "top":
        await top_songs(callback.message)
    elif action == "settings":
        await settings_cmd(callback.message)
    elif action == "help":
        await help_cmd(callback.message)
    await callback.answer()

@dp.callback_query(F.data.startswith("search_"))
async def search_again(callback: types.CallbackQuery):
    query = callback.data[7:]
    await callback.answer()
    await do_search(callback.message, query)

@dp.callback_query()
async def other_callbacks(callback: types.CallbackQuery):
    await callback.answer()

# ===================== ISHGA TUSHIRISH =====================

async def main():
    logger.info("Bot ishga tushmoqda...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
