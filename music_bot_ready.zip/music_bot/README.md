# 🎵 Musiqa Bot — O'rnatish Qo'llanmasi

## Bot imkoniyatlari:
- YouTube, Instagram, TikTok, Spotify, SoundCloud dan musiqa yuklab olish
- Qo'shiq nomi yoki artist bo'yicha qidirish
- Link yuborish orqali yuklab olish
- Shaxsiy pleylist saqlash
- Top qo'shiqlar

---

## 1-qadam: Bot token olish

1. Telegramda [@BotFather](https://t.me/BotFather) ga o'ting
2. `/newbot` yozing
3. Bot nomini kiriting (masalan: `Musiqa Bot`)
4. Bot username kiriting (masalan: `musiqa_uz_bot`)
5. **Token** ni nusxalab oling — u shunday ko'rinadi:
   ```
   1234567890:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```

---

## 2-qadam: Railway ga deploy qilish (BEPUL)

### 2.1 GitHub ga yuklash:
1. [github.com](https://github.com) ga kiring (akkaunt oching)
2. **New repository** tugmasini bosing
3. Nom bering: `music-bot`
4. **Create repository** bosing
5. Fayllarni yuklang:
   - `bot.py`
   - `requirements.txt`
   - `railway.toml`
   - `nixpacks.toml`

### 2.2 Railway ga ulash:
1. [railway.app](https://railway.app) ga kiring
2. **GitHub** bilan kiring
3. **New Project** → **Deploy from GitHub repo**
4. `music-bot` ni tanlang
5. **Variables** bo'limiga o'ting
6. `BOT_TOKEN` = sizning tokeningiz — qo'shing
7. **Deploy** tugmasini bosing ✅

---

## Tayyor! Botingiz ishlaydi 🎉

Bot quyidagi buyruqlarga javob beradi:
- `/start` — boshlash
- `/song [nom]` — qo'shiq qidirish  
- `/artist [ism]` — artist bo'yicha qidirish
- `/my` — mening pleylistim
- `/top` — top qo'shiqlar
- `/help` — yordam
- **Link yuborish** — YouTube/TikTok/Instagram link yuklab olish
